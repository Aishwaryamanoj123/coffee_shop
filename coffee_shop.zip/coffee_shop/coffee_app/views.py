from django.shortcuts import render
from django.http import HttpResponse
from .models import coffee
from django.conf import settings
from django.core.mail import send_mail


def home(request):
    Coffee = coffee.objects.all()
    # return HttpResponse('<h1>Home page</h1>')
    return render(request, 'home.html', {'coffee':Coffee}) 



def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')

        subject = 'ContactForm'
        message = f'there is a message from {name}\n email {email}.  The message is {message} .Thankyou'
        email_from = settings.EMAIL_HOST_USER
        recipient_list = [settings.EMAIL_HOST_USER]
        send_mail(subject, message, email_from, recipient_list)

        
        subject = 'Thank you for submitting the ContactForm'
        message_body = f'Hi {name},Thank you for submitting the form.'
        email_from = settings.EMAIL_HOST_USER
        recipient_list = [email]
        send_mail(subject, message_body, email_from, recipient_list)

       
        return render(request, "index.html")
    else:
        return render(request, "contact.html")

 
    
    


        

       


    